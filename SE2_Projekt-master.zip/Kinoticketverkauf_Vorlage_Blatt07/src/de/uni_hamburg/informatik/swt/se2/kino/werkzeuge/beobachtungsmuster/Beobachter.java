package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.beobachtungsmuster;


/**
 * Interface des Beobachters.
 * @author Skadi
 *
 */
public interface Beobachter
{
    public void beachteAenderung();
}
