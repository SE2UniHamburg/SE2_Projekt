package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.beobachtungsmuster;

import java.util.*;

/* TODO comments */
/**
 * Abstrakte Klasse Beobachtbar
 * kann Aenderungen melden und Beobachter setzen.
 * @author Skadi
 *
 */
public abstract class Beobachtbar
{
	// der Beobachter
    private HashSet<Beobachter> _beobachter = new HashSet<Beobachter>();
    
    /**
     * Meldet Aenderung an alle.
     */
    protected void meldeAenderung()
    {
        _beobachter.forEach(beobachter -> beobachter.beachteAenderung());
    }
    
    /**
     * Fügt einen neuen Beobachter hinzu.
     * @param b der neue Beobachter
     */
    public void setzeBeobachter(Beobachter b)
    {
        _beobachter.add(b);
    }
}
